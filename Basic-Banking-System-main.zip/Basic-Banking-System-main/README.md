# Basic-Banking-System
The Sparks Banking consists of many activities that can be done through a number of financial institutions that accept deposits from individuals and other entities, and then use this money to offer loans, and to invest and earn profit.

The Spark Bank is just an project under the The sparks foundation as a part of intersnship. In which a dynamic website 
has to be created with dummy 10 users and transaction to be made between them .Technologies:
HTML,CSS as a frontend 
PHP as backend 
MYSQL as a database.   
